<?php 
$__title 		= get_the_archive_title();
$__description 	= get_the_archive_description();
$__keywords 	= "archive, " . get_the_archive_title(); 
$__canonical 	= home_url(add_query_arg(NULL, NULL));
?>
<?php get_header(); ?>
		<?php 
		if(have_posts()) 
		{
		?>
			<main class="container">
				<section>
					<header class="page-header">
						<?php
							the_archive_title( '<h1>', '</h1>' );
							the_archive_description( '<div>', '</div>' );
						?>
					</header>
				</section>
				<?php
				while(have_posts())
				{
					the_post();
					?>
					<article>
						<header>
							<?php the_title( '<h1>', '</h1>' ); ?>
						</header>
						<div>
							<?php the_content(); ?>
						</div>
						<footer>
							<?php
							$post_tags = get_the_tags();

							if($post_tags) 
							{
								$output = "";

								foreach($post_tags as $tag) 
								{
									$output .= '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a> ';
								}
							}

							echo $output;
							?>
						</footer>
					</article>
					<?php
				}
			?>
			</div>
		<?php
		}
		?>
<?php get_footer(); ?>