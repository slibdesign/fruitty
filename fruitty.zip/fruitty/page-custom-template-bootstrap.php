<?php /* Template Name: Bootstrap */ ?>
<?php 
$__title 		= "Bootstrap | Fruitty.co.uk - HTML 1st WordPress theme";
$__description 	= "Bootstrap custom WordPress page tenmplate by Fruitty";
$__keywords 	= "bootstrap, custom wordpress page template"; 
$__canonical 	= get_permalink();
?>
<?php get_header(); ?>
		<?php 
		if(have_posts()) 
		{
			while(have_posts())
			{
				the_post();
				?>
				<section class="container">
					<div class="row">
						<div class="col-12">
							<h2>Bootstrap Grid</h2>
							<?php the_content(); ?>
							<p>The most popular HTML, CSS, and JS library in the world grid layout features. Basic grid layouts to get you familiar with building within the Bootstrap grid system.</p>
						</div>
					</div>
					<div class="row mb-3">
						<div class="col-xs-12 col-md-4 themed-grid-col"><span class="col-internal">.col-xs-12 .col-md-4</span></div>
						<div class="col-xs-12 col-md-4 themed-grid-col"><span class="col-internal">.col-xs-12 .col-md-4</span></div>
						<div class="col-xs-12 col-md-4 themed-grid-col"><span class="col-internal">.col-xs-12 .col-md-4</span></div>
					</div>
					<div class="row mb-3">
						<div class="col-sm themed-grid-col"><span class="col-internal">.col-sm</span></div>
						<div class="col-sm themed-grid-col"><span class="col-internal">.col-sm</span></div>
						<div class="col-sm themed-grid-col"><span class="col-internal">.col-sm</span></div>
					</div>
					<div class="row mb-3 text-center">
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
						<div class="col-1 col-xs-12 themed-grid-col"><span class="col-internal"></span></div>
					</div>
					<div class="row mb-3 text-center">
						<div class="col-xs-12 col-md-6 themed-grid-col"><span class="col-internal">.col-6<br>.col-xs-12</span></div>
						<div class="col-xs-12 col-md-6 themed-grid-col"><span class="col-internal">.col-6<br>.col-xs-12</span></div>
					</div>
					<div class="row mb-3 text-center">
						<div class="col-2 themed-grid-col"><span class="col-internal">.col-2</span></div>
						<div class="col-2 themed-grid-col"><span class="col-internal">.col-2</span></div>
						<div class="col-2 themed-grid-col"><span class="col-internal">.col-2</span></div>
						<div class="col-2 themed-grid-col"><span class="col-internal">.col-2</span></div>
						<div class="col-2 themed-grid-col"><span class="col-internal">.col-2</span></div>
						<div class="col-2 themed-grid-col"><span class="col-internal">.col-2</span></div>
					</div>
					<div class="row mb-3 text-center">
						<div class="col-md-8 themed-grid-col"><span class="col-internal">.col-8</span></div>
						<div class="col-md-4 themed-grid-col"><span class="col-internal">.col-4</span></div>
					</div>
					<div class="row mb-3 text-center">
						<div class="col-3 themed-grid-col"><span class="col-internal">.col-3</span></div>
						<div class="col-3 themed-grid-col"><span class="col-internal">.col-3</span></div>
						<div class="col-3 themed-grid-col"><span class="col-internal">.col-3</span></div>
						<div class="col-3 themed-grid-col"><span class="col-internal">.col-3</span></div>
					</div>
					<div class="row mb-3">
						<div class="col themed-grid-col">
							<span class="col-internal">.col</span>
						</div>
						<div class="col themed-grid-col">
							<span class="col-internal">.col</span>
						</div>
						<div class="col themed-grid-col">
							<span class="col-internal">.col</span>
						</div>
					</div>
					<div class="row mb-3 text-center">
						<div class="col-2 themed-grid-col"><span class="col-internal">.col-2</span></div>
						<div class="col-10 themed-grid-col"><span class="col-internal">.col-10</span></div>
					</div>
					<div class="row mb-3">
						<div class="col-sm-8 themed-grid-col"><span class="col-internal">col-sm-8</span></div>
						<div class="col-sm-4 themed-grid-col"><span class="col-internal">col-sm-4</span></div>
					</div>
					
				</section>
		<?php
		}
	}
	?>
<?php get_footer(); ?>