=== Fruitty ===
Contributors: fruitty.co.uk
Requires at least: 4.4
Tested up to: 6.8
Requires PHP: 5.2.4
Version: 3.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: fruitty

== Description ==
Fruitty - HTML 1st WordPress theme. Bootstrap Grid, Pico minimalist starter kit and Lineicons together in one theme.

For more information about Fruitty please go to https://www.fruitty.co.uk.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add' button.
2. Type in Twenty Sixteen in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.

== Changelog ==

= 1.0 =
* Released: 12/05/2025

https://www.fruitty.co.uk/fruitty.zip