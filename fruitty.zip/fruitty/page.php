<?php 
$__title 		= get_the_title();
$__description 	= get_the_excerpt();
$__keywords 	= "page, " . get_the_title(); 
$__canonical 	= get_permalink();
?>
<?php get_header(); ?>
		<main class="container">
			<?php 
			if(have_posts()) 
			{
			?>
				<?php
				while(have_posts())
				{
					the_post();
					?>
					<article>
						<header>
							<?php the_title( '<h1>', '</h1>' ); ?>
						</header>
						<div>
							<?php the_content(); ?>
						</div>
					</article>
					<?php
				}
			}
			?>
		</main>
<?php get_footer(); ?>