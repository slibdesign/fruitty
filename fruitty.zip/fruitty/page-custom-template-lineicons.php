<?php /* Template Name: Lineicons */ ?>
<?php 
$__title 		= "Lineicons | Fruitty.co.uk - HTML 1st WordPress theme";
$__description 	= "Lineicons custom WordPress page tenmplate by Fruitty";
$__keywords 	= "lineicons, custom wordpress page template"; 
$__canonical 	= get_permalink(); 
?>
<?php get_header(); ?>
		<?php 
		if(have_posts()) 
		{
			while(have_posts())
			{
				the_post();
				?>
				<main class="container">
					<section>
						<div class="row">
							<div class="col-12">
								<h1>Lineicons</h1>
								<p>1315+ high-quality icons with unique styles and versatility.</p>
								<?php the_content(); ?>
							</div>
						</div>
					</section>
					<section class="icons">
						<ul>
							<li>
								<i class="lni lni-500px"></i>
								<p class="js-classname">lni-500px</p>

							</li>

							<li>
								<i class="lni lni-adobe"></i>
								<p class="js-classname">lni-adobe</p>

							</li>

							<li>
								<i class="lni lni-adonis"></i>
								<p class="js-classname">lni-adonis</p>

							</li>

							<li>
								<i class="lni lni-aeroplane-1"></i>
								<p class="js-classname">lni-aeroplane-1</p>

							</li>

							<li>
								<i class="lni lni-agenda"></i>
								<p class="js-classname">lni-agenda</p>

							</li>

							<li>
								<i class="lni lni-airbnb"></i>
								<p class="js-classname">lni-airbnb</p>

							</li>

							<li>
								<i class="lni lni-airtable"></i>
								<p class="js-classname">lni-airtable</p>

							</li>

							<li>
								<i class="lni lni-alarm-1"></i>
								<p class="js-classname">lni-alarm-1</p>

							</li>

							<li>
								<i class="lni lni-align-text-center"></i>
								<p class="js-classname">lni-align-text-center</p>

							</li>

							<li>
								<i class="lni lni-align-text-left"></i>
								<p class="js-classname">lni-align-text-left</p>

							</li>

							<li>
								<i class="lni lni-align-text-right"></i>
								<p class="js-classname">lni-align-text-right</p>

							</li>

							<li>
								<i class="lni lni-alpinejs"></i>
								<p class="js-classname">lni-alpinejs</p>

							</li>

							<li>
								<i class="lni lni-amazon"></i>
								<p class="js-classname">lni-amazon</p>

							</li>

							<li>
								<i class="lni lni-amazon-original"></i>
								<p class="js-classname">lni-amazon-original</p>

							</li>

							<li>
								<i class="lni lni-amazon-pay"></i>
								<p class="js-classname">lni-amazon-pay</p>

							</li>

							<li>
								<i class="lni lni-ambulance-1"></i>
								<p class="js-classname">lni-ambulance-1</p>

							</li>

							<li>
								<i class="lni lni-amd"></i>
								<p class="js-classname">lni-amd</p>

							</li>

							<li>
								<i class="lni lni-amex"></i>
								<p class="js-classname">lni-amex</p>

							</li>

							<li>
								<i class="lni lni-anchor"></i>
								<p class="js-classname">lni-anchor</p>

							</li>

							<li>
								<i class="lni lni-android"></i>
								<p class="js-classname">lni-android</p>

							</li>

							<li>
								<i class="lni lni-android-old"></i>
								<p class="js-classname">lni-android-old</p>

							</li>

							<li>
								<i class="lni lni-angellist"></i>
								<p class="js-classname">lni-angellist</p>

							</li>

							<li>
								<i class="lni lni-angle-double-down"></i>
								<p class="js-classname">lni-angle-double-down</p>

							</li>

							<li>
								<i class="lni lni-angle-double-left"></i>
								<p class="js-classname">lni-angle-double-left</p>

							</li>

							<li>
								<i class="lni lni-angle-double-right"></i>
								<p class="js-classname">lni-angle-double-right</p>

							</li>

							<li>
								<i class="lni lni-angle-double-up"></i>
								<p class="js-classname">lni-angle-double-up</p>

							</li>

							<li>
								<i class="lni lni-angular"></i>
								<p class="js-classname">lni-angular</p>

							</li>

							<li>
								<i class="lni lni-app-store"></i>
								<p class="js-classname">lni-app-store</p>

							</li>

							<li>
								<i class="lni lni-apple-brand"></i>
								<p class="js-classname">lni-apple-brand</p>

							</li>

							<li>
								<i class="lni lni-apple-music"></i>
								<p class="js-classname">lni-apple-music</p>

							</li>

							<li>
								<i class="lni lni-apple-music-alt"></i>
								<p class="js-classname">lni-apple-music-alt</p>

							</li>

							<li>
								<i class="lni lni-apple-pay"></i>
								<p class="js-classname">lni-apple-pay</p>

							</li>

							<li>
								<i class="lni lni-arc-browser"></i>
								<p class="js-classname">lni-arc-browser</p>

							</li>

							<li>
								<i class="lni lni-arrow-all-direction"></i>
								<p class="js-classname">lni-arrow-all-direction</p>

							</li>

							<li>
								<i class="lni lni-arrow-angular-top-left"></i>
								<p class="js-classname">lni-arrow-angular-top-left</p>

							</li>

							<li>
								<i class="lni lni-arrow-angular-top-right"></i>
								<p class="js-classname">lni-arrow-angular-top-right</p>

							</li>

							<li>
								<i class="lni lni-arrow-both-direction-horizontal-1"></i>
								<p class="js-classname">lni-arrow-both-direction-horizontal-1</p>

							</li>

							<li>
								<i class="lni lni-arrow-both-direction-vertical-1"></i>
								<p class="js-classname">lni-arrow-both-direction-vertical-1</p>

							</li>

							<li>
								<i class="lni lni-arrow-downward"></i>
								<p class="js-classname">lni-arrow-downward</p>

							</li>

							<li>
								<i class="lni lni-arrow-left"></i>
								<p class="js-classname">lni-arrow-left</p>

							</li>

							<li>
								<i class="lni lni-arrow-left-circle"></i>
								<p class="js-classname">lni-arrow-left-circle</p>

							</li>

							<li>
								<i class="lni lni-arrow-right"></i>
								<p class="js-classname">lni-arrow-right</p>

							</li>

							<li>
								<i class="lni lni-arrow-right-circle"></i>
								<p class="js-classname">lni-arrow-right-circle</p>

							</li>

							<li>
								<i class="lni lni-arrow-upward"></i>
								<p class="js-classname">lni-arrow-upward</p>

							</li>

							<li>
								<i class="lni lni-asana"></i>
								<p class="js-classname">lni-asana</p>

							</li>

							<li>
								<i class="lni lni-astro"></i>
								<p class="js-classname">lni-astro</p>

							</li>

							<li>
								<i class="lni lni-atlassian"></i>
								<p class="js-classname">lni-atlassian</p>

							</li>

							<li>
								<i class="lni lni-audi"></i>
								<p class="js-classname">lni-audi</p>

							</li>

							<li>
								<i class="lni lni-audi-alt"></i>
								<p class="js-classname">lni-audi-alt</p>

							</li>

							<li>
								<i class="lni lni-aws"></i>
								<p class="js-classname">lni-aws</p>

							</li>

							<li>
								<i class="lni lni-azure"></i>
								<p class="js-classname">lni-azure</p>

							</li>

							<li>
								<i class="lni lni-badge-decagram-percent"></i>
								<p class="js-classname">lni-badge-decagram-percent</p>

							</li>

							<li>
								<i class="lni lni-balloons"></i>
								<p class="js-classname">lni-balloons</p>

							</li>

							<li>
								<i class="lni lni-ban-2"></i>
								<p class="js-classname">lni-ban-2</p>

							</li>

							<li>
								<i class="lni lni-bar-chart-4"></i>
								<p class="js-classname">lni-bar-chart-4</p>

							</li>

							<li>
								<i class="lni lni-bar-chart-dollar"></i>
								<p class="js-classname">lni-bar-chart-dollar</p>

							</li>

							<li>
								<i class="lni lni-basket-shopping-3"></i>
								<p class="js-classname">lni-basket-shopping-3</p>

							</li>

							<li>
								<i class="lni lni-beat"></i>
								<p class="js-classname">lni-beat</p>

							</li>

							<li>
								<i class="lni lni-behance"></i>
								<p class="js-classname">lni-behance</p>

							</li>

							<li>
								<i class="lni lni-bell-1"></i>
								<p class="js-classname">lni-bell-1</p>

							</li>

							<li>
								<i class="lni lni-bike"></i>
								<p class="js-classname">lni-bike</p>

							</li>

							<li>
								<i class="lni lni-bing"></i>
								<p class="js-classname">lni-bing</p>

							</li>

							<li>
								<i class="lni lni-bitbucket"></i>
								<p class="js-classname">lni-bitbucket</p>

							</li>

							<li>
								<i class="lni lni-bitcoin"></i>
								<p class="js-classname">lni-bitcoin</p>

							</li>

							<li>
								<i class="lni lni-bittorrent"></i>
								<p class="js-classname">lni-bittorrent</p>

							</li>

							<li>
								<i class="lni lni-blogger"></i>
								<p class="js-classname">lni-blogger</p>

							</li>

							<li>
								<i class="lni lni-blogger-alt"></i>
								<p class="js-classname">lni-blogger-alt</p>

							</li>

							<li>
								<i class="lni lni-bluetooth"></i>
								<p class="js-classname">lni-bluetooth</p>

							</li>

							<li>
								<i class="lni lni-bluetooth-logo"></i>
								<p class="js-classname">lni-bluetooth-logo</p>

							</li>

							<li>
								<i class="lni lni-bmw"></i>
								<p class="js-classname">lni-bmw</p>

							</li>

							<li>
								<i class="lni lni-board-writing-3"></i>
								<p class="js-classname">lni-board-writing-3</p>

							</li>

							<li>
								<i class="lni lni-bold"></i>
								<p class="js-classname">lni-bold</p>

							</li>

							<li>
								<i class="lni lni-bolt-2"></i>
								<p class="js-classname">lni-bolt-2</p>

							</li>

							<li>
								<i class="lni lni-bolt-3"></i>
								<p class="js-classname">lni-bolt-3</p>

							</li>

							<li>
								<i class="lni lni-book-1"></i>
								<p class="js-classname">lni-book-1</p>

							</li>

							<li>
								<i class="lni lni-bookmark-1"></i>
								<p class="js-classname">lni-bookmark-1</p>

							</li>

							<li>
								<i class="lni lni-bookmark-circle"></i>
								<p class="js-classname">lni-bookmark-circle</p>

							</li>

							<li>
								<i class="lni lni-books-2"></i>
								<p class="js-classname">lni-books-2</p>

							</li>

							<li>
								<i class="lni lni-bootstrap-5"></i>
								<p class="js-classname">lni-bootstrap-5</p>

							</li>

							<li>
								<i class="lni lni-bootstrap-5-square"></i>
								<p class="js-classname">lni-bootstrap-5-square</p>

							</li>

							<li>
								<i class="lni lni-box-archive-1"></i>
								<p class="js-classname">lni-box-archive-1</p>

							</li>

							<li>
								<i class="lni lni-box-closed"></i>
								<p class="js-classname">lni-box-closed</p>

							</li>

							<li>
								<i class="lni lni-box-gift-1"></i>
								<p class="js-classname">lni-box-gift-1</p>

							</li>

							<li>
								<i class="lni lni-brave"></i>
								<p class="js-classname">lni-brave</p>

							</li>

							<li>
								<i class="lni lni-bricks"></i>
								<p class="js-classname">lni-bricks</p>

							</li>

							<li>
								<i class="lni lni-bridge-3"></i>
								<p class="js-classname">lni-bridge-3</p>

							</li>

							<li>
								<i class="lni lni-briefcase-1"></i>
								<p class="js-classname">lni-briefcase-1</p>

							</li>

							<li>
								<i class="lni lni-briefcase-2"></i>
								<p class="js-classname">lni-briefcase-2</p>

							</li>

							<li>
								<i class="lni lni-briefcase-plus-1"></i>
								<p class="js-classname">lni-briefcase-plus-1</p>

							</li>

							<li>
								<i class="lni lni-brush-1-rotated"></i>
								<p class="js-classname">lni-brush-1-rotated</p>

							</li>

							<li>
								<i class="lni lni-brush-2"></i>
								<p class="js-classname">lni-brush-2</p>

							</li>

							<li>
								<i class="lni lni-btc"></i>
								<p class="js-classname">lni-btc</p>

							</li>

							<li>
								<i class="lni lni-bug-1"></i>
								<p class="js-classname">lni-bug-1</p>

							</li>

							<li>
								<i class="lni lni-buildings-1"></i>
								<p class="js-classname">lni-buildings-1</p>

							</li>

							<li>
								<i class="lni lni-bulb-2"></i>
								<p class="js-classname">lni-bulb-2</p>

							</li>

							<li>
								<i class="lni lni-bulb-4"></i>
								<p class="js-classname">lni-bulb-4</p>

							</li>

							<li>
								<i class="lni lni-burger-1"></i>
								<p class="js-classname">lni-burger-1</p>

							</li>

							<li>
								<i class="lni lni-burger-drink"></i>
								<p class="js-classname">lni-burger-drink</p>

							</li>

							<li>
								<i class="lni lni-bus-1"></i>
								<p class="js-classname">lni-bus-1</p>

							</li>

							<li>
								<i class="lni lni-busket-ball"></i>
								<p class="js-classname">lni-busket-ball</p>

							</li>

							<li>
								<i class="lni lni-cake-1"></i>
								<p class="js-classname">lni-cake-1</p>

							</li>

							<li>
								<i class="lni lni-calculator-1"></i>
								<p class="js-classname">lni-calculator-1</p>

							</li>

							<li>
								<i class="lni lni-calculator-2"></i>
								<p class="js-classname">lni-calculator-2</p>

							</li>

							<li>
								<i class="lni lni-calendar-days"></i>
								<p class="js-classname">lni-calendar-days</p>

							</li>

							<li>
								<i class="lni lni-camera-1"></i>
								<p class="js-classname">lni-camera-1</p>

							</li>

							<li>
								<i class="lni lni-camera-movie-1"></i>
								<p class="js-classname">lni-camera-movie-1</p>

							</li>

							<li>
								<i class="lni lni-candy-cane-2"></i>
								<p class="js-classname">lni-candy-cane-2</p>

							</li>

							<li>
								<i class="lni lni-candy-round-1"></i>
								<p class="js-classname">lni-candy-round-1</p>

							</li>

							<li>
								<i class="lni lni-canva"></i>
								<p class="js-classname">lni-canva</p>

							</li>

							<li>
								<i class="lni lni-capsule-1"></i>
								<p class="js-classname">lni-capsule-1</p>

							</li>

							<li>
								<i class="lni lni-car-2"></i>
								<p class="js-classname">lni-car-2</p>

							</li>

							<li>
								<i class="lni lni-car-4"></i>
								<p class="js-classname">lni-car-4</p>

							</li>

							<li>
								<i class="lni lni-car-6"></i>
								<p class="js-classname">lni-car-6</p>

							</li>

							<li>
								<i class="lni lni-caravan-1"></i>
								<p class="js-classname">lni-caravan-1</p>

							</li>

							<li>
								<i class="lni lni-cart-1"></i>
								<p class="js-classname">lni-cart-1</p>

							</li>

							<li>
								<i class="lni lni-cart-2"></i>
								<p class="js-classname">lni-cart-2</p>

							</li>

							<li>
								<i class="lni lni-cash-app"></i>
								<p class="js-classname">lni-cash-app</p>

							</li>

							<li>
								<i class="lni lni-certificate-badge-1"></i>
								<p class="js-classname">lni-certificate-badge-1</p>

							</li>

							<li>
								<i class="lni lni-chat-bubble-2"></i>
								<p class="js-classname">lni-chat-bubble-2</p>

							</li>

							<li>
								<i class="lni lni-check"></i>
								<p class="js-classname">lni-check</p>

							</li>

							<li>
								<i class="lni lni-check-circle-1"></i>
								<p class="js-classname">lni-check-circle-1</p>

							</li>

							<li>
								<i class="lni lni-check-square-2"></i>
								<p class="js-classname">lni-check-square-2</p>

							</li>

							<li>
								<i class="lni lni-chevron-down"></i>
								<p class="js-classname">lni-chevron-down</p>

							</li>

							<li>
								<i class="lni lni-chevron-down-circle"></i>
								<p class="js-classname">lni-chevron-down-circle</p>

							</li>

							<li>
								<i class="lni lni-chevron-left"></i>
								<p class="js-classname">lni-chevron-left</p>

							</li>

							<li>
								<i class="lni lni-chevron-left-circle"></i>
								<p class="js-classname">lni-chevron-left-circle</p>

							</li>

							<li>
								<i class="lni lni-chevron-right-circle"></i>
								<p class="js-classname">lni-chevron-right-circle</p>

							</li>

							<li>
								<i class="lni lni-chevron-up"></i>
								<p class="js-classname">lni-chevron-up</p>

							</li>

							<li>
								<i class="lni lni-chevron-up-circle"></i>
								<p class="js-classname">lni-chevron-up-circle</p>

							</li>

							<li>
								<i class="lni lni-chrome"></i>
								<p class="js-classname">lni-chrome</p>

							</li>

							<li>
								<i class="lni lni-chromecast"></i>
								<p class="js-classname">lni-chromecast</p>

							</li>

							<li>
								<i class="lni lni-cisco"></i>
								<p class="js-classname">lni-cisco</p>

							</li>

							<li>
								<i class="lni lni-claude"></i>
								<p class="js-classname">lni-claude</p>

							</li>

							<li>
								<i class="lni lni-clickup"></i>
								<p class="js-classname">lni-clickup</p>

							</li>

							<li>
								<i class="lni lni-clipboard"></i>
								<p class="js-classname">lni-clipboard</p>

							</li>

							<li>
								<i class="lni lni-cloud-2"></i>
								<p class="js-classname">lni-cloud-2</p>

							</li>

							<li>
								<i class="lni lni-cloud-bolt-1"></i>
								<p class="js-classname">lni-cloud-bolt-1</p>

							</li>

							<li>
								<i class="lni lni-cloud-bolt-2"></i>
								<p class="js-classname">lni-cloud-bolt-2</p>

							</li>

							<li>
								<i class="lni lni-cloud-check-circle"></i>
								<p class="js-classname">lni-cloud-check-circle</p>

							</li>

							<li>
								<i class="lni lni-cloud-download"></i>
								<p class="js-classname">lni-cloud-download</p>

							</li>

							<li>
								<i class="lni lni-cloud-iot-2"></i>
								<p class="js-classname">lni-cloud-iot-2</p>

							</li>

							<li>
								<i class="lni lni-cloud-rain"></i>
								<p class="js-classname">lni-cloud-rain</p>

							</li>

							<li>
								<i class="lni lni-cloud-refresh-clockwise"></i>
								<p class="js-classname">lni-cloud-refresh-clockwise</p>

							</li>

							<li>
								<i class="lni lni-cloud-sun"></i>
								<p class="js-classname">lni-cloud-sun</p>

							</li>

							<li>
								<i class="lni lni-cloud-upload"></i>
								<p class="js-classname">lni-cloud-upload</p>

							</li>

							<li>
								<i class="lni lni-cloudflare"></i>
								<p class="js-classname">lni-cloudflare</p>

							</li>

							<li>
								<i class="lni lni-code-1"></i>
								<p class="js-classname">lni-code-1</p>

							</li>

							<li>
								<i class="lni lni-code-s"></i>
								<p class="js-classname">lni-code-s</p>

							</li>

							<li>
								<i class="lni lni-codepen"></i>
								<p class="js-classname">lni-codepen</p>

							</li>

							<li>
								<i class="lni lni-coffee-cup-2"></i>
								<p class="js-classname">lni-coffee-cup-2</p>

							</li>

							<li>
								<i class="lni lni-coinbase"></i>
								<p class="js-classname">lni-coinbase</p>

							</li>

							<li>
								<i class="lni lni-colour-palette-3"></i>
								<p class="js-classname">lni-colour-palette-3</p>

							</li>

							<li>
								<i class="lni lni-comment-1"></i>
								<p class="js-classname">lni-comment-1</p>

							</li>

							<li>
								<i class="lni lni-comment-1-share"></i>
								<p class="js-classname">lni-comment-1-share</p>

							</li>

							<li>
								<i class="lni lni-comment-1-text"></i>
								<p class="js-classname">lni-comment-1-text</p>

							</li>

							<li>
								<i class="lni lni-compass-drafting-2"></i>
								<p class="js-classname">lni-compass-drafting-2</p>

							</li>

							<li>
								<i class="lni lni-connectdevelop"></i>
								<p class="js-classname">lni-connectdevelop</p>

							</li>

							<li>
								<i class="lni lni-copilot"></i>
								<p class="js-classname">lni-copilot</p>

							</li>

							<li>
								<i class="lni lni-coral"></i>
								<p class="js-classname">lni-coral</p>

							</li>

							<li>
								<i class="lni lni-cpanel"></i>
								<p class="js-classname">lni-cpanel</p>

							</li>

							<li>
								<i class="lni lni-crane-4"></i>
								<p class="js-classname">lni-crane-4</p>

							</li>

							<li>
								<i class="lni lni-creative-commons"></i>
								<p class="js-classname">lni-creative-commons</p>

							</li>

							<li>
								<i class="lni lni-credit-card-multiple"></i>
								<p class="js-classname">lni-credit-card-multiple</p>

							</li>

							<li>
								<i class="lni lni-crop-2"></i>
								<p class="js-classname">lni-crop-2</p>

							</li>

							<li>
								<i class="lni lni-crown-3"></i>
								<p class="js-classname">lni-crown-3</p>

							</li>

							<li>
								<i class="lni lni-css3"></i>
								<p class="js-classname">lni-css3</p>

							</li>

							<li>
								<i class="lni lni-dashboard-square-1"></i>
								<p class="js-classname">lni-dashboard-square-1</p>

							</li>

							<li>
								<i class="lni lni-database-2"></i>
								<p class="js-classname">lni-database-2</p>

							</li>

							<li>
								<i class="lni lni-deno"></i>
								<p class="js-classname">lni-deno</p>

							</li>

							<li>
								<i class="lni lni-dev"></i>
								<p class="js-classname">lni-dev</p>

							</li>

							<li>
								<i class="lni lni-dialogflow"></i>
								<p class="js-classname">lni-dialogflow</p>

							</li>

							<li>
								<i class="lni lni-diamonds-1"></i>
								<p class="js-classname">lni-diamonds-1</p>

							</li>

							<li>
								<i class="lni lni-diamonds-2"></i>
								<p class="js-classname">lni-diamonds-2</p>

							</li>

							<li>
								<i class="lni lni-digitalocean"></i>
								<p class="js-classname">lni-digitalocean</p>

							</li>

							<li>
								<i class="lni lni-diners-club"></i>
								<p class="js-classname">lni-diners-club</p>

							</li>

							<li>
								<i class="lni lni-direction-ltr"></i>
								<p class="js-classname">lni-direction-ltr</p>

							</li>

							<li>
								<i class="lni lni-direction-rtl"></i>
								<p class="js-classname">lni-direction-rtl</p>

							</li>

							<li>
								<i class="lni lni-discord"></i>
								<p class="js-classname">lni-discord</p>

							</li>

							<li>
								<i class="lni lni-discord-chat"></i>
								<p class="js-classname">lni-discord-chat</p>

							</li>

							<li>
								<i class="lni lni-discover"></i>
								<p class="js-classname">lni-discover</p>

							</li>

							<li>
								<i class="lni lni-docker"></i>
								<p class="js-classname">lni-docker</p>

							</li>

							<li>
								<i class="lni lni-dollar"></i>
								<p class="js-classname">lni-dollar</p>

							</li>

							<li>
								<i class="lni lni-dollar-circle"></i>
								<p class="js-classname">lni-dollar-circle</p>

							</li>

							<li>
								<i class="lni lni-double-quotes-end-1"></i>
								<p class="js-classname">lni-double-quotes-end-1</p>

							</li>

							<li>
								<i class="lni lni-download-1"></i>
								<p class="js-classname">lni-download-1</p>

							</li>

							<li>
								<i class="lni lni-download-circle-1"></i>
								<p class="js-classname">lni-download-circle-1</p>

							</li>

							<li>
								<i class="lni lni-dribbble"></i>
								<p class="js-classname">lni-dribbble</p>

							</li>

							<li>
								<i class="lni lni-dribbble-symbol"></i>
								<p class="js-classname">lni-dribbble-symbol</p>

							</li>

							<li>
								<i class="lni lni-drizzle"></i>
								<p class="js-classname">lni-drizzle</p>

							</li>

							<li>
								<i class="lni lni-dropbox"></i>
								<p class="js-classname">lni-dropbox</p>

							</li>

							<li>
								<i class="lni lni-drupal"></i>
								<p class="js-classname">lni-drupal</p>

							</li>

							<li>
								<i class="lni lni-dumbbell-1"></i>
								<p class="js-classname">lni-dumbbell-1</p>

							</li>

							<li>
								<i class="lni lni-edge"></i>
								<p class="js-classname">lni-edge</p>

							</li>

							<li>
								<i class="lni lni-emoji-expressionless"></i>
								<p class="js-classname">lni-emoji-expressionless</p>

							</li>

							<li>
								<i class="lni lni-emoji-expressionless-flat-eyes"></i>
								<p class="js-classname">lni-emoji-expressionless-flat-eyes</p>

							</li>

							<li>
								<i class="lni lni-emoji-grin"></i>
								<p class="js-classname">lni-emoji-grin</p>

							</li>

							<li>
								<i class="lni lni-emoji-sad"></i>
								<p class="js-classname">lni-emoji-sad</p>

							</li>

							<li>
								<i class="lni lni-emoji-smile"></i>
								<p class="js-classname">lni-emoji-smile</p>

							</li>

							<li>
								<i class="lni lni-emoji-smile-side"></i>
								<p class="js-classname">lni-emoji-smile-side</p>

							</li>

							<li>
								<i class="lni lni-emoji-smile-sunglass"></i>
								<p class="js-classname">lni-emoji-smile-sunglass</p>

							</li>

							<li>
								<i class="lni lni-emoji-smile-tongue"></i>
								<p class="js-classname">lni-emoji-smile-tongue</p>

							</li>

							<li>
								<i class="lni lni-enter"></i>
								<p class="js-classname">lni-enter</p>

							</li>

							<li>
								<i class="lni lni-enter-down"></i>
								<p class="js-classname">lni-enter-down</p>

							</li>

							<li>
								<i class="lni lni-envato"></i>
								<p class="js-classname">lni-envato</p>

							</li>

							<li>
								<i class="lni lni-envelope-1"></i>
								<p class="js-classname">lni-envelope-1</p>

							</li>

							<li>
								<i class="lni lni-eraser-1"></i>
								<p class="js-classname">lni-eraser-1</p>

							</li>

							<li>
								<i class="lni lni-ethereum-logo"></i>
								<p class="js-classname">lni-ethereum-logo</p>

							</li>

							<li>
								<i class="lni lni-euro"></i>
								<p class="js-classname">lni-euro</p>

							</li>

							<li>
								<i class="lni lni-exit"></i>
								<p class="js-classname">lni-exit</p>

							</li>

							<li>
								<i class="lni lni-exit-up"></i>
								<p class="js-classname">lni-exit-up</p>

							</li>

							<li>
								<i class="lni lni-expand-arrow-1"></i>
								<p class="js-classname">lni-expand-arrow-1</p>

							</li>

							<li>
								<i class="lni lni-expand-square-4"></i>
								<p class="js-classname">lni-expand-square-4</p>

							</li>

							<li>
								<i class="lni lni-expressjs"></i>
								<p class="js-classname">lni-expressjs</p>

							</li>

							<li>
								<i class="lni lni-eye"></i>
								<p class="js-classname">lni-eye</p>

							</li>

							<li>
								<i class="lni lni-facebook"></i>
								<p class="js-classname">lni-facebook</p>

							</li>

							<li>
								<i class="lni lni-facebook-messenger"></i>
								<p class="js-classname">lni-facebook-messenger</p>

							</li>

							<li>
								<i class="lni lni-facebook-rounded"></i>
								<p class="js-classname">lni-facebook-rounded</p>

							</li>

							<li>
								<i class="lni lni-facebook-square"></i>
								<p class="js-classname">lni-facebook-square</p>

							</li>

							<li>
								<i class="lni lni-facetime"></i>
								<p class="js-classname">lni-facetime</p>

							</li>

							<li>
								<i class="lni lni-figma"></i>
								<p class="js-classname">lni-figma</p>

							</li>

							<li>
								<i class="lni lni-file-format-zip"></i>
								<p class="js-classname">lni-file-format-zip</p>

							</li>

							<li>
								<i class="lni lni-file-multiple"></i>
								<p class="js-classname">lni-file-multiple</p>

							</li>

							<li>
								<i class="lni lni-file-pencil"></i>
								<p class="js-classname">lni-file-pencil</p>

							</li>

							<li>
								<i class="lni lni-file-plus-circle"></i>
								<p class="js-classname">lni-file-plus-circle</p>

							</li>

							<li>
								<i class="lni lni-file-question"></i>
								<p class="js-classname">lni-file-question</p>

							</li>

							<li>
								<i class="lni lni-file-xmark"></i>
								<p class="js-classname">lni-file-xmark</p>

							</li>

							<li>
								<i class="lni lni-firebase"></i>
								<p class="js-classname">lni-firebase</p>

							</li>

							<li>
								<i class="lni lni-firefox"></i>
								<p class="js-classname">lni-firefox</p>

							</li>

							<li>
								<i class="lni lni-firework-rocket-4"></i>
								<p class="js-classname">lni-firework-rocket-4</p>

							</li>

							<li>
								<i class="lni lni-fitbit"></i>
								<p class="js-classname">lni-fitbit</p>

							</li>

							<li>
								<i class="lni lni-flag-1"></i>
								<p class="js-classname">lni-flag-1</p>

							</li>

							<li>
								<i class="lni lni-flag-2"></i>
								<p class="js-classname">lni-flag-2</p>

							</li>

							<li>
								<i class="lni lni-flickr"></i>
								<p class="js-classname">lni-flickr</p>

							</li>

							<li>
								<i class="lni lni-floppy-disk-1"></i>
								<p class="js-classname">lni-floppy-disk-1</p>

							</li>

							<li>
								<i class="lni lni-flower-2"></i>
								<p class="js-classname">lni-flower-2</p>

							</li>

							<li>
								<i class="lni lni-flutter"></i>
								<p class="js-classname">lni-flutter</p>

							</li>

							<li>
								<i class="lni lni-folder-1"></i>
								<p class="js-classname">lni-folder-1</p>

							</li>

							<li>
								<i class="lni lni-ford"></i>
								<p class="js-classname">lni-ford</p>

							</li>

							<li>
								<i class="lni lni-framer"></i>
								<p class="js-classname">lni-framer</p>

							</li>

							<li>
								<i class="lni lni-funnel-1"></i>
								<p class="js-classname">lni-funnel-1</p>

							</li>

							<li>
								<i class="lni lni-gallery"></i>
								<p class="js-classname">lni-gallery</p>

							</li>

							<li>
								<i class="lni lni-game-pad-modern-1"></i>
								<p class="js-classname">lni-game-pad-modern-1</p>

							</li>

							<li>
								<i class="lni lni-gatsby"></i>
								<p class="js-classname">lni-gatsby</p>

							</li>

							<li>
								<i class="lni lni-gauge-1"></i>
								<p class="js-classname">lni-gauge-1</p>

							</li>

							<li>
								<i class="lni lni-gear-1"></i>
								<p class="js-classname">lni-gear-1</p>

							</li>

							<li>
								<i class="lni lni-gears-3"></i>
								<p class="js-classname">lni-gears-3</p>

							</li>

							<li>
								<i class="lni lni-gemini"></i>
								<p class="js-classname">lni-gemini</p>

							</li>

							<li>
								<i class="lni lni-git"></i>
								<p class="js-classname">lni-git</p>

							</li>

							<li>
								<i class="lni lni-github"></i>
								<p class="js-classname">lni-github</p>

							</li>

							<li>
								<i class="lni lni-glass-juice-1"></i>
								<p class="js-classname">lni-glass-juice-1</p>

							</li>

							<li>
								<i class="lni lni-globe-1"></i>
								<p class="js-classname">lni-globe-1</p>

							</li>

							<li>
								<i class="lni lni-globe-stand"></i>
								<p class="js-classname">lni-globe-stand</p>

							</li>

							<li>
								<i class="lni lni-go"></i>
								<p class="js-classname">lni-go</p>

							</li>

							<li>
								<i class="lni lni-goodreads"></i>
								<p class="js-classname">lni-goodreads</p>

							</li>

							<li>
								<i class="lni lni-google"></i>
								<p class="js-classname">lni-google</p>

							</li>

							<li>
								<i class="lni lni-google-cloud"></i>
								<p class="js-classname">lni-google-cloud</p>

							</li>

							<li>
								<i class="lni lni-google-drive"></i>
								<p class="js-classname">lni-google-drive</p>

							</li>

							<li>
								<i class="lni lni-google-meet"></i>
								<p class="js-classname">lni-google-meet</p>

							</li>

							<li>
								<i class="lni lni-google-pay"></i>
								<p class="js-classname">lni-google-pay</p>

							</li>

							<li>
								<i class="lni lni-google-wallet"></i>
								<p class="js-classname">lni-google-wallet</p>

							</li>

							<li>
								<i class="lni lni-graduation-cap-1"></i>
								<p class="js-classname">lni-graduation-cap-1</p>

							</li>

							<li>
								<i class="lni lni-grammarly"></i>
								<p class="js-classname">lni-grammarly</p>

							</li>

							<li>
								<i class="lni lni-hacker-news"></i>
								<p class="js-classname">lni-hacker-news</p>

							</li>

							<li>
								<i class="lni lni-hammer-1"></i>
								<p class="js-classname">lni-hammer-1</p>

							</li>

							<li>
								<i class="lni lni-hammer-2"></i>
								<p class="js-classname">lni-hammer-2</p>

							</li>

							<li>
								<i class="lni lni-hand-mic"></i>
								<p class="js-classname">lni-hand-mic</p>

							</li>

							<li>
								<i class="lni lni-hand-shake"></i>
								<p class="js-classname">lni-hand-shake</p>

							</li>

							<li>
								<i class="lni lni-hand-stop"></i>
								<p class="js-classname">lni-hand-stop</p>

							</li>

							<li>
								<i class="lni lni-hand-taking-dollar"></i>
								<p class="js-classname">lni-hand-taking-dollar</p>

							</li>

							<li>
								<i class="lni lni-hand-taking-leaf-1"></i>
								<p class="js-classname">lni-hand-taking-leaf-1</p>

							</li>

							<li>
								<i class="lni lni-hand-taking-user"></i>
								<p class="js-classname">lni-hand-taking-user</p>

							</li>

							<li>
								<i class="lni lni-hashnode"></i>
								<p class="js-classname">lni-hashnode</p>

							</li>

							<li>
								<i class="lni lni-hat-chef-3"></i>
								<p class="js-classname">lni-hat-chef-3</p>

							</li>

							<li>
								<i class="lni lni-headphone-1"></i>
								<p class="js-classname">lni-headphone-1</p>

							</li>

							<li>
								<i class="lni lni-heart"></i>
								<p class="js-classname">lni-heart</p>

							</li>

							<li>
								<i class="lni lni-helicopter-2"></i>
								<p class="js-classname">lni-helicopter-2</p>

							</li>

							<li>
								<i class="lni lni-helmet-safety-1"></i>
								<p class="js-classname">lni-helmet-safety-1</p>

							</li>

							<li>
								<i class="lni lni-hierarchy-1"></i>
								<p class="js-classname">lni-hierarchy-1</p>

							</li>

							<li>
								<i class="lni lni-highlighter-1"></i>
								<p class="js-classname">lni-highlighter-1</p>

							</li>

							<li>
								<i class="lni lni-highlighter-2"></i>
								<p class="js-classname">lni-highlighter-2</p>

							</li>

							<li>
								<i class="lni lni-home-2"></i>
								<p class="js-classname">lni-home-2</p>

							</li>

							<li>
								<i class="lni lni-hospital-2"></i>
								<p class="js-classname">lni-hospital-2</p>

							</li>

							<li>
								<i class="lni lni-hourglass"></i>
								<p class="js-classname">lni-hourglass</p>

							</li>

							<li>
								<i class="lni lni-html5"></i>
								<p class="js-classname">lni-html5</p>

							</li>

							<li>
								<i class="lni lni-ibm"></i>
								<p class="js-classname">lni-ibm</p>

							</li>

							<li>
								<i class="lni lni-id-card"></i>
								<p class="js-classname">lni-id-card</p>

							</li>

							<li>
								<i class="lni lni-imdb"></i>
								<p class="js-classname">lni-imdb</p>

							</li>

							<li>
								<i class="lni lni-indent"></i>
								<p class="js-classname">lni-indent</p>

							</li>

							<li>
								<i class="lni lni-info"></i>
								<p class="js-classname">lni-info</p>

							</li>

							<li>
								<i class="lni lni-injection-1"></i>
								<p class="js-classname">lni-injection-1</p>

							</li>

							<li>
								<i class="lni lni-instagram"></i>
								<p class="js-classname">lni-instagram</p>

							</li>

							<li>
								<i class="lni lni-instagram-logotype"></i>
								<p class="js-classname">lni-instagram-logotype</p>

							</li>

							<li>
								<i class="lni lni-intel"></i>
								<p class="js-classname">lni-intel</p>

							</li>

							<li>
								<i class="lni lni-ios"></i>
								<p class="js-classname">lni-ios</p>

							</li>

							<li>
								<i class="lni lni-island-2"></i>
								<p class="js-classname">lni-island-2</p>

							</li>

							<li>
								<i class="lni lni-jaguar"></i>
								<p class="js-classname">lni-jaguar</p>

							</li>

							<li>
								<i class="lni lni-jamstack"></i>
								<p class="js-classname">lni-jamstack</p>

							</li>

							<li>
								<i class="lni lni-java"></i>
								<p class="js-classname">lni-java</p>

							</li>

							<li>
								<i class="lni lni-javascript"></i>
								<p class="js-classname">lni-javascript</p>

							</li>

							<li>
								<i class="lni lni-jcb"></i>
								<p class="js-classname">lni-jcb</p>

							</li>

							<li>
								<i class="lni lni-joomla"></i>
								<p class="js-classname">lni-joomla</p>

							</li>

							<li>
								<i class="lni lni-jsfiddle"></i>
								<p class="js-classname">lni-jsfiddle</p>

							</li>

							<li>
								<i class="lni lni-key-1"></i>
								<p class="js-classname">lni-key-1</p>

							</li>

							<li>
								<i class="lni lni-keyboard"></i>
								<p class="js-classname">lni-keyboard</p>

							</li>

							<li>
								<i class="lni lni-knife-fork-1"></i>
								<p class="js-classname">lni-knife-fork-1</p>

							</li>

							<li>
								<i class="lni lni-kubernetes"></i>
								<p class="js-classname">lni-kubernetes</p>

							</li>

							<li>
								<i class="lni lni-label-dollar-2"></i>
								<p class="js-classname">lni-label-dollar-2</p>

							</li>

							<li>
								<i class="lni lni-laptop-2"></i>
								<p class="js-classname">lni-laptop-2</p>

							</li>

							<li>
								<i class="lni lni-laptop-phone"></i>
								<p class="js-classname">lni-laptop-phone</p>

							</li>

							<li>
								<i class="lni lni-laravel"></i>
								<p class="js-classname">lni-laravel</p>

							</li>

							<li>
								<i class="lni lni-layers-1"></i>
								<p class="js-classname">lni-layers-1</p>

							</li>

							<li>
								<i class="lni lni-layout-26"></i>
								<p class="js-classname">lni-layout-26</p>

							</li>

							<li>
								<i class="lni lni-layout-9"></i>
								<p class="js-classname">lni-layout-9</p>

							</li>

							<li>
								<i class="lni lni-leaf-1"></i>
								<p class="js-classname">lni-leaf-1</p>

							</li>

							<li>
								<i class="lni lni-leaf-6"></i>
								<p class="js-classname">lni-leaf-6</p>

							</li>

							<li>
								<i class="lni lni-lemon-squeezy"></i>
								<p class="js-classname">lni-lemon-squeezy</p>

							</li>

							<li>
								<i class="lni lni-life-guard-tube-1"></i>
								<p class="js-classname">lni-life-guard-tube-1</p>

							</li>

							<li>
								<i class="lni lni-line"></i>
								<p class="js-classname">lni-line</p>

							</li>

							<li>
								<i class="lni lni-line-dashed"></i>
								<p class="js-classname">lni-line-dashed</p>

							</li>

							<li>
								<i class="lni lni-line-dotted"></i>
								<p class="js-classname">lni-line-dotted</p>

							</li>

							<li>
								<i class="lni lni-line-height"></i>
								<p class="js-classname">lni-line-height</p>

							</li>

							<li>
								<i class="lni lni-lineicons"></i>
								<p class="js-classname">lni-lineicons</p>

							</li>

							<li>
								<i class="lni lni-link-2-angular-right"></i>
								<p class="js-classname">lni-link-2-angular-right</p>

							</li>

							<li>
								<i class="lni lni-linkedin"></i>
								<p class="js-classname">lni-linkedin</p>

							</li>

							<li>
								<i class="lni lni-location-arrow-right"></i>
								<p class="js-classname">lni-location-arrow-right</p>

							</li>

							<li>
								<i class="lni lni-locked-1"></i>
								<p class="js-classname">lni-locked-1</p>

							</li>

							<li>
								<i class="lni lni-locked-2"></i>
								<p class="js-classname">lni-locked-2</p>

							</li>

							<li>
								<i class="lni lni-loom"></i>
								<p class="js-classname">lni-loom</p>

							</li>

							<li>
								<i class="lni lni-magento"></i>
								<p class="js-classname">lni-magento</p>

							</li>

							<li>
								<i class="lni lni-magnet"></i>
								<p class="js-classname">lni-magnet</p>

							</li>

							<li>
								<i class="lni lni-mailchimp"></i>
								<p class="js-classname">lni-mailchimp</p>

							</li>

							<li>
								<i class="lni lni-map-marker-1"></i>
								<p class="js-classname">lni-map-marker-1</p>

							</li>

							<li>
								<i class="lni lni-map-marker-5"></i>
								<p class="js-classname">lni-map-marker-5</p>

							</li>

							<li>
								<i class="lni lni-map-pin-5"></i>
								<p class="js-classname">lni-map-pin-5</p>

							</li>

							<li>
								<i class="lni lni-markdown"></i>
								<p class="js-classname">lni-markdown</p>

							</li>

							<li>
								<i class="lni lni-mastercard"></i>
								<p class="js-classname">lni-mastercard</p>

							</li>

							<li>
								<i class="lni lni-medium"></i>
								<p class="js-classname">lni-medium</p>

							</li>

							<li>
								<i class="lni lni-medium-alt"></i>
								<p class="js-classname">lni-medium-alt</p>

							</li>

							<li>
								<i class="lni lni-megaphone-1"></i>
								<p class="js-classname">lni-megaphone-1</p>

							</li>

							<li>
								<i class="lni lni-menu-cheesburger"></i>
								<p class="js-classname">lni-menu-cheesburger</p>

							</li>

							<li>
								<i class="lni lni-menu-hamburger-1"></i>
								<p class="js-classname">lni-menu-hamburger-1</p>

							</li>

							<li>
								<i class="lni lni-menu-meatballs-1"></i>
								<p class="js-classname">lni-menu-meatballs-1</p>

							</li>

							<li>
								<i class="lni lni-menu-meatballs-2"></i>
								<p class="js-classname">lni-menu-meatballs-2</p>

							</li>

							<li>
								<i class="lni lni-mercedes"></i>
								<p class="js-classname">lni-mercedes</p>

							</li>

							<li>
								<i class="lni lni-message-2"></i>
								<p class="js-classname">lni-message-2</p>

							</li>

							<li>
								<i class="lni lni-message-2-question"></i>
								<p class="js-classname">lni-message-2-question</p>

							</li>

							<li>
								<i class="lni lni-message-3-text"></i>
								<p class="js-classname">lni-message-3-text</p>

							</li>

							<li>
								<i class="lni lni-meta"></i>
								<p class="js-classname">lni-meta</p>

							</li>

							<li>
								<i class="lni lni-meta-alt"></i>
								<p class="js-classname">lni-meta-alt</p>

							</li>

							<li>
								<i class="lni lni-microphone-1"></i>
								<p class="js-classname">lni-microphone-1</p>

							</li>

							<li>
								<i class="lni lni-microscope"></i>
								<p class="js-classname">lni-microscope</p>

							</li>

							<li>
								<i class="lni lni-microsoft"></i>
								<p class="js-classname">lni-microsoft</p>

							</li>

							<li>
								<i class="lni lni-microsoft-edge"></i>
								<p class="js-classname">lni-microsoft-edge</p>

							</li>

							<li>
								<i class="lni lni-microsoft-teams"></i>
								<p class="js-classname">lni-microsoft-teams</p>

							</li>

							<li>
								<i class="lni lni-minus"></i>
								<p class="js-classname">lni-minus</p>

							</li>

							<li>
								<i class="lni lni-minus-circle"></i>
								<p class="js-classname">lni-minus-circle</p>

							</li>

							<li>
								<i class="lni lni-mongodb"></i>
								<p class="js-classname">lni-mongodb</p>

							</li>

							<li>
								<i class="lni lni-monitor"></i>
								<p class="js-classname">lni-monitor</p>

							</li>

							<li>
								<i class="lni lni-monitor-code"></i>
								<p class="js-classname">lni-monitor-code</p>

							</li>

							<li>
								<i class="lni lni-monitor-mac"></i>
								<p class="js-classname">lni-monitor-mac</p>

							</li>

							<li>
								<i class="lni lni-moon-half-right-5"></i>
								<p class="js-classname">lni-moon-half-right-5</p>

							</li>

							<li>
								<i class="lni lni-mountains-2"></i>
								<p class="js-classname">lni-mountains-2</p>

							</li>

							<li>
								<i class="lni lni-mouse-2"></i>
								<p class="js-classname">lni-mouse-2</p>

							</li>

							<li>
								<i class="lni lni-mushroom-1"></i>
								<p class="js-classname">lni-mushroom-1</p>

							</li>

							<li>
								<i class="lni lni-mushroom-5"></i>
								<p class="js-classname">lni-mushroom-5</p>

							</li>

							<li>
								<i class="lni lni-music"></i>
								<p class="js-classname">lni-music</p>

							</li>

							<li>
								<i class="lni lni-mysql"></i>
								<p class="js-classname">lni-mysql</p>

							</li>

							<li>
								<i class="lni lni-nasa"></i>
								<p class="js-classname">lni-nasa</p>

							</li>

							<li>
								<i class="lni lni-netflix"></i>
								<p class="js-classname">lni-netflix</p>

							</li>

							<li>
								<i class="lni lni-netlify"></i>
								<p class="js-classname">lni-netlify</p>

							</li>

							<li>
								<i class="lni lni-next-step-2"></i>
								<p class="js-classname">lni-next-step-2</p>

							</li>

							<li>
								<i class="lni lni-nextjs"></i>
								<p class="js-classname">lni-nextjs</p>

							</li>

							<li>
								<i class="lni lni-nike"></i>
								<p class="js-classname">lni-nike</p>

							</li>

							<li>
								<i class="lni lni-nissan"></i>
								<p class="js-classname">lni-nissan</p>

							</li>

							<li>
								<i class="lni lni-nodejs"></i>
								<p class="js-classname">lni-nodejs</p>

							</li>

							<li>
								<i class="lni lni-nodejs-alt"></i>
								<p class="js-classname">lni-nodejs-alt</p>

							</li>

							<li>
								<i class="lni lni-notebook-1"></i>
								<p class="js-classname">lni-notebook-1</p>

							</li>

							<li>
								<i class="lni lni-notion"></i>
								<p class="js-classname">lni-notion</p>

							</li>

							<li>
								<i class="lni lni-npm"></i>
								<p class="js-classname">lni-npm</p>

							</li>

							<li>
								<i class="lni lni-nuxt"></i>
								<p class="js-classname">lni-nuxt</p>

							</li>

							<li>
								<i class="lni lni-nvidia"></i>
								<p class="js-classname">lni-nvidia</p>

							</li>

							<li>
								<i class="lni lni-oculus"></i>
								<p class="js-classname">lni-oculus</p>

							</li>

							<li>
								<i class="lni lni-open-ai"></i>
								<p class="js-classname">lni-open-ai</p>

							</li>

							<li>
								<i class="lni lni-opera-mini"></i>
								<p class="js-classname">lni-opera-mini</p>

							</li>

							<li>
								<i class="lni lni-oracle"></i>
								<p class="js-classname">lni-oracle</p>

							</li>

							<li>
								<i class="lni lni-outdent"></i>
								<p class="js-classname">lni-outdent</p>

							</li>

							<li>
								<i class="lni lni-paddle"></i>
								<p class="js-classname">lni-paddle</p>

							</li>

							<li>
								<i class="lni lni-page-break-1"></i>
								<p class="js-classname">lni-page-break-1</p>

							</li>

							<li>
								<i class="lni lni-pagination"></i>
								<p class="js-classname">lni-pagination</p>

							</li>

							<li>
								<i class="lni lni-paint-bucket"></i>
								<p class="js-classname">lni-paint-bucket</p>

							</li>

							<li>
								<i class="lni lni-paint-roller-1"></i>
								<p class="js-classname">lni-paint-roller-1</p>

							</li>

							<li>
								<i class="lni lni-paperclip-1"></i>
								<p class="js-classname">lni-paperclip-1</p>

							</li>

							<li>
								<i class="lni lni-party-flags"></i>
								<p class="js-classname">lni-party-flags</p>

							</li>

							<li>
								<i class="lni lni-party-spray"></i>
								<p class="js-classname">lni-party-spray</p>

							</li>

							<li>
								<i class="lni lni-patreon"></i>
								<p class="js-classname">lni-patreon</p>

							</li>

							<li>
								<i class="lni lni-pause"></i>
								<p class="js-classname">lni-pause</p>

							</li>

							<li>
								<i class="lni lni-payoneer"></i>
								<p class="js-classname">lni-payoneer</p>

							</li>

							<li>
								<i class="lni lni-paypal"></i>
								<p class="js-classname">lni-paypal</p>

							</li>

							<li>
								<i class="lni lni-pen-to-square"></i>
								<p class="js-classname">lni-pen-to-square</p>

							</li>

							<li>
								<i class="lni lni-pencil-1"></i>
								<p class="js-classname">lni-pencil-1</p>

							</li>

							<li>
								<i class="lni lni-pepsi"></i>
								<p class="js-classname">lni-pepsi</p>

							</li>

							<li>
								<i class="lni lni-phone"></i>
								<p class="js-classname">lni-phone</p>

							</li>

							<li>
								<i class="lni lni-photos"></i>
								<p class="js-classname">lni-photos</p>

							</li>

							<li>
								<i class="lni lni-php"></i>
								<p class="js-classname">lni-php</p>

							</li>

							<li>
								<i class="lni lni-pie-chart-2"></i>
								<p class="js-classname">lni-pie-chart-2</p>

							</li>

							<li>
								<i class="lni lni-pilcrow"></i>
								<p class="js-classname">lni-pilcrow</p>

							</li>

							<li>
								<i class="lni lni-pimjo-logo"></i>
								<p class="js-classname">lni-pimjo-logo</p>

							</li>

							<li>
								<i class="lni lni-pimjo-symbol"></i>
								<p class="js-classname">lni-pimjo-symbol</p>

							</li>

							<li>
								<i class="lni lni-pinterest"></i>
								<p class="js-classname">lni-pinterest</p>

							</li>

							<li>
								<i class="lni lni-pizza-2"></i>
								<p class="js-classname">lni-pizza-2</p>

							</li>

							<li>
								<i class="lni lni-placeholder-dollar"></i>
								<p class="js-classname">lni-placeholder-dollar</p>

							</li>

							<li>
								<i class="lni lni-plantscale"></i>
								<p class="js-classname">lni-plantscale</p>

							</li>

							<li>
								<i class="lni lni-play"></i>
								<p class="js-classname">lni-play</p>

							</li>

							<li>
								<i class="lni lni-play-store"></i>
								<p class="js-classname">lni-play-store</p>

							</li>

							<li>
								<i class="lni lni-playstation"></i>
								<p class="js-classname">lni-playstation</p>

							</li>

							<li>
								<i class="lni lni-plug-1"></i>
								<p class="js-classname">lni-plug-1</p>

							</li>

							<li>
								<i class="lni lni-plus"></i>
								<p class="js-classname">lni-plus</p>

							</li>

							<li>
								<i class="lni lni-plus-circle"></i>
								<p class="js-classname">lni-plus-circle</p>

							</li>

							<li>
								<i class="lni lni-pnpm"></i>
								<p class="js-classname">lni-pnpm</p>

							</li>

							<li>
								<i class="lni lni-postgresql"></i>
								<p class="js-classname">lni-postgresql</p>

							</li>

							<li>
								<i class="lni lni-postman"></i>
								<p class="js-classname">lni-postman</p>

							</li>

							<li>
								<i class="lni lni-pound"></i>
								<p class="js-classname">lni-pound</p>

							</li>

							<li>
								<i class="lni lni-power-button"></i>
								<p class="js-classname">lni-power-button</p>

							</li>

							<li>
								<i class="lni lni-previous-step-2"></i>
								<p class="js-classname">lni-previous-step-2</p>

							</li>

							<li>
								<i class="lni lni-printer"></i>
								<p class="js-classname">lni-printer</p>

							</li>

							<li>
								<i class="lni lni-prisma"></i>
								<p class="js-classname">lni-prisma</p>

							</li>

							<li>
								<i class="lni lni-producthunt"></i>
								<p class="js-classname">lni-producthunt</p>

							</li>

							<li>
								<i class="lni lni-proton-mail-logo"></i>
								<p class="js-classname">lni-proton-mail-logo</p>

							</li>

							<li>
								<i class="lni lni-proton-mail-symbol"></i>
								<p class="js-classname">lni-proton-mail-symbol</p>

							</li>

							<li>
								<i class="lni lni-python"></i>
								<p class="js-classname">lni-python</p>

							</li>

							<li>
								<i class="lni lni-question-mark"></i>
								<p class="js-classname">lni-question-mark</p>

							</li>

							<li>
								<i class="lni lni-question-mark-circle"></i>
								<p class="js-classname">lni-question-mark-circle</p>

							</li>

							<li>
								<i class="lni lni-quora"></i>
								<p class="js-classname">lni-quora</p>

							</li>

							<li>
								<i class="lni lni-radis"></i>
								<p class="js-classname">lni-radis</p>

							</li>

							<li>
								<i class="lni lni-react"></i>
								<p class="js-classname">lni-react</p>

							</li>

							<li>
								<i class="lni lni-reddit"></i>
								<p class="js-classname">lni-reddit</p>

							</li>

							<li>
								<i class="lni lni-refresh-circle-1-clockwise"></i>
								<p class="js-classname">lni-refresh-circle-1-clockwise</p>

							</li>

							<li>
								<i class="lni lni-refresh-dollar-1"></i>
								<p class="js-classname">lni-refresh-dollar-1</p>

							</li>

							<li>
								<i class="lni lni-refresh-user-1"></i>
								<p class="js-classname">lni-refresh-user-1</p>

							</li>

							<li>
								<i class="lni lni-remix-js"></i>
								<p class="js-classname">lni-remix-js</p>

							</li>

							<li>
								<i class="lni lni-road-1"></i>
								<p class="js-classname">lni-road-1</p>

							</li>

							<li>
								<i class="lni lni-rocket-5"></i>
								<p class="js-classname">lni-rocket-5</p>

							</li>

							<li>
								<i class="lni lni-route-1"></i>
								<p class="js-classname">lni-route-1</p>

							</li>

							<li>
								<i class="lni lni-rss-right"></i>
								<p class="js-classname">lni-rss-right</p>

							</li>

							<li>
								<i class="lni lni-ruler-1"></i>
								<p class="js-classname">lni-ruler-1</p>

							</li>

							<li>
								<i class="lni lni-ruler-pen"></i>
								<p class="js-classname">lni-ruler-pen</p>

							</li>

							<li>
								<i class="lni lni-rupee"></i>
								<p class="js-classname">lni-rupee</p>

							</li>

							<li>
								<i class="lni lni-safari"></i>
								<p class="js-classname">lni-safari</p>

							</li>

							<li>
								<i class="lni lni-sanity"></i>
								<p class="js-classname">lni-sanity</p>

							</li>

							<li>
								<i class="lni lni-school-bench-1"></i>
								<p class="js-classname">lni-school-bench-1</p>

							</li>

							<li>
								<i class="lni lni-school-bench-2"></i>
								<p class="js-classname">lni-school-bench-2</p>

							</li>

							<li>
								<i class="lni lni-scissors-1-vertical"></i>
								<p class="js-classname">lni-scissors-1-vertical</p>

							</li>

							<li>
								<i class="lni lni-scoter"></i>
								<p class="js-classname">lni-scoter</p>

							</li>

							<li>
								<i class="lni lni-scroll-down-2"></i>
								<p class="js-classname">lni-scroll-down-2</p>

							</li>

							<li>
								<i class="lni lni-search-1"></i>
								<p class="js-classname">lni-search-1</p>

							</li>

							<li>
								<i class="lni lni-search-2"></i>
								<p class="js-classname">lni-search-2</p>

							</li>

							<li>
								<i class="lni lni-search-minus"></i>
								<p class="js-classname">lni-search-minus</p>

							</li>

							<li>
								<i class="lni lni-search-plus"></i>
								<p class="js-classname">lni-search-plus</p>

							</li>

							<li>
								<i class="lni lni-search-text"></i>
								<p class="js-classname">lni-search-text</p>

							</li>

							<li>
								<i class="lni lni-select-cursor-1"></i>
								<p class="js-classname">lni-select-cursor-1</p>

							</li>

							<li>
								<i class="lni lni-seo-monitor"></i>
								<p class="js-classname">lni-seo-monitor</p>

							</li>

							<li>
								<i class="lni lni-service-bell-1"></i>
								<p class="js-classname">lni-service-bell-1</p>

							</li>

							<li>
								<i class="lni lni-share-1"></i>
								<p class="js-classname">lni-share-1</p>

							</li>

							<li>
								<i class="lni lni-share-1-circle"></i>
								<p class="js-classname">lni-share-1-circle</p>

							</li>

							<li>
								<i class="lni lni-share-2"></i>
								<p class="js-classname">lni-share-2</p>

							</li>

							<li>
								<i class="lni lni-shield-2"></i>
								<p class="js-classname">lni-shield-2</p>

							</li>

							<li>
								<i class="lni lni-shield-2-check"></i>
								<p class="js-classname">lni-shield-2-check</p>

							</li>

							<li>
								<i class="lni lni-shield-dollar"></i>
								<p class="js-classname">lni-shield-dollar</p>

							</li>

							<li>
								<i class="lni lni-shift-left"></i>
								<p class="js-classname">lni-shift-left</p>

							</li>

							<li>
								<i class="lni lni-shift-right"></i>
								<p class="js-classname">lni-shift-right</p>

							</li>

							<li>
								<i class="lni lni-ship-1"></i>
								<p class="js-classname">lni-ship-1</p>

							</li>

							<li>
								<i class="lni lni-shirt-1"></i>
								<p class="js-classname">lni-shirt-1</p>

							</li>

							<li>
								<i class="lni lni-shopify"></i>
								<p class="js-classname">lni-shopify</p>

							</li>

							<li>
								<i class="lni lni-shovel"></i>
								<p class="js-classname">lni-shovel</p>

							</li>

							<li>
								<i class="lni lni-shuffle"></i>
								<p class="js-classname">lni-shuffle</p>

							</li>

							<li>
								<i class="lni lni-sign-post-left"></i>
								<p class="js-classname">lni-sign-post-left</p>

							</li>

							<li>
								<i class="lni lni-signal-app"></i>
								<p class="js-classname">lni-signal-app</p>

							</li>

							<li>
								<i class="lni lni-signs-post-2"></i>
								<p class="js-classname">lni-signs-post-2</p>

							</li>

							<li>
								<i class="lni lni-sketch"></i>
								<p class="js-classname">lni-sketch</p>

							</li>

							<li>
								<i class="lni lni-skype"></i>
								<p class="js-classname">lni-skype</p>

							</li>

							<li>
								<i class="lni lni-slack"></i>
								<p class="js-classname">lni-slack</p>

							</li>

							<li>
								<i class="lni lni-slice-2"></i>
								<p class="js-classname">lni-slice-2</p>

							</li>

							<li>
								<i class="lni lni-sliders-horizontal-square-2"></i>
								<p class="js-classname">lni-sliders-horizontal-square-2</p>

							</li>

							<li>
								<i class="lni lni-slideshare"></i>
								<p class="js-classname">lni-slideshare</p>

							</li>

							<li>
								<i class="lni lni-snapchat"></i>
								<p class="js-classname">lni-snapchat</p>

							</li>

							<li>
								<i class="lni lni-sort-alphabetical"></i>
								<p class="js-classname">lni-sort-alphabetical</p>

							</li>

							<li>
								<i class="lni lni-sort-high-to-low"></i>
								<p class="js-classname">lni-sort-high-to-low</p>

							</li>

							<li>
								<i class="lni lni-soundcloud"></i>
								<p class="js-classname">lni-soundcloud</p>

							</li>

							<li>
								<i class="lni lni-spacex"></i>
								<p class="js-classname">lni-spacex</p>

							</li>

							<li>
								<i class="lni lni-spellcheck"></i>
								<p class="js-classname">lni-spellcheck</p>

							</li>

							<li>
								<i class="lni lni-spinner-2-sacle"></i>
								<p class="js-classname">lni-spinner-2-sacle</p>

							</li>

							<li>
								<i class="lni lni-spinner-3"></i>
								<p class="js-classname">lni-spinner-3</p>

							</li>

							<li>
								<i class="lni lni-sports"></i>
								<p class="js-classname">lni-sports</p>

							</li>

							<li>
								<i class="lni lni-spotify"></i>
								<p class="js-classname">lni-spotify</p>

							</li>

							<li>
								<i class="lni lni-spotify-alt"></i>
								<p class="js-classname">lni-spotify-alt</p>

							</li>

							<li>
								<i class="lni lni-squarespace"></i>
								<p class="js-classname">lni-squarespace</p>

							</li>

							<li>
								<i class="lni lni-stackoverflow"></i>
								<p class="js-classname">lni-stackoverflow</p>

							</li>

							<li>
								<i class="lni lni-stamp"></i>
								<p class="js-classname">lni-stamp</p>

							</li>

							<li>
								<i class="lni lni-star-fat"></i>
								<p class="js-classname">lni-star-fat</p>

							</li>

							<li>
								<i class="lni lni-star-fat-half-2"></i>
								<p class="js-classname">lni-star-fat-half-2</p>

							</li>

							<li>
								<i class="lni lni-star-sharp-disabled"></i>
								<p class="js-classname">lni-star-sharp-disabled</p>

							</li>

							<li>
								<i class="lni lni-statista"></i>
								<p class="js-classname">lni-statista</p>

							</li>

							<li>
								<i class="lni lni-steam"></i>
								<p class="js-classname">lni-steam</p>

							</li>

							<li>
								<i class="lni lni-stethoscope-1"></i>
								<p class="js-classname">lni-stethoscope-1</p>

							</li>

							<li>
								<i class="lni lni-stopwatch"></i>
								<p class="js-classname">lni-stopwatch</p>

							</li>

							<li>
								<i class="lni lni-storage-hdd-2"></i>
								<p class="js-classname">lni-storage-hdd-2</p>

							</li>

							<li>
								<i class="lni lni-strikethrough-1"></i>
								<p class="js-classname">lni-strikethrough-1</p>

							</li>

							<li>
								<i class="lni lni-stripe"></i>
								<p class="js-classname">lni-stripe</p>

							</li>

							<li>
								<i class="lni lni-stumbleupon"></i>
								<p class="js-classname">lni-stumbleupon</p>

							</li>

							<li>
								<i class="lni lni-sun-1"></i>
								<p class="js-classname">lni-sun-1</p>

							</li>

							<li>
								<i class="lni lni-supabase"></i>
								<p class="js-classname">lni-supabase</p>

							</li>

							<li>
								<i class="lni lni-surfboard-2"></i>
								<p class="js-classname">lni-surfboard-2</p>

							</li>

							<li>
								<i class="lni lni-svelte"></i>
								<p class="js-classname">lni-svelte</p>

							</li>

							<li>
								<i class="lni lni-swift"></i>
								<p class="js-classname">lni-swift</p>

							</li>

							<li>
								<i class="lni lni-tab"></i>
								<p class="js-classname">lni-tab</p>

							</li>

							<li>
								<i class="lni lni-tailwindcss"></i>
								<p class="js-classname">lni-tailwindcss</p>

							</li>

							<li>
								<i class="lni lni-target-user"></i>
								<p class="js-classname">lni-target-user</p>

							</li>

							<li>
								<i class="lni lni-telegram"></i>
								<p class="js-classname">lni-telegram</p>

							</li>

							<li>
								<i class="lni lni-telephone-1"></i>
								<p class="js-classname">lni-telephone-1</p>

							</li>

							<li>
								<i class="lni lni-telephone-3"></i>
								<p class="js-classname">lni-telephone-3</p>

							</li>

							<li>
								<i class="lni lni-tesla"></i>
								<p class="js-classname">lni-tesla</p>

							</li>

							<li>
								<i class="lni lni-text-format"></i>
								<p class="js-classname">lni-text-format</p>

							</li>

							<li>
								<i class="lni lni-text-format-remove"></i>
								<p class="js-classname">lni-text-format-remove</p>

							</li>

							<li>
								<i class="lni lni-text-paragraph"></i>
								<p class="js-classname">lni-text-paragraph</p>

							</li>

							<li>
								<i class="lni lni-thumbs-down-3"></i>
								<p class="js-classname">lni-thumbs-down-3</p>

							</li>

							<li>
								<i class="lni lni-thumbs-up-3"></i>
								<p class="js-classname">lni-thumbs-up-3</p>

							</li>

							<li>
								<i class="lni lni-ticket-1"></i>
								<p class="js-classname">lni-ticket-1</p>

							</li>

							<li>
								<i class="lni lni-tickets-3"></i>
								<p class="js-classname">lni-tickets-3</p>

							</li>

							<li>
								<i class="lni lni-tiktok"></i>
								<p class="js-classname">lni-tiktok</p>

							</li>

							<li>
								<i class="lni lni-tiktok-alt"></i>
								<p class="js-classname">lni-tiktok-alt</p>

							</li>

							<li>
								<i class="lni lni-tower-broadcast-1"></i>
								<p class="js-classname">lni-tower-broadcast-1</p>

							</li>

							<li>
								<i class="lni lni-toyota"></i>
								<p class="js-classname">lni-toyota</p>

							</li>

							<li>
								<i class="lni lni-train-1"></i>
								<p class="js-classname">lni-train-1</p>

							</li>

							<li>
								<i class="lni lni-train-3"></i>
								<p class="js-classname">lni-train-3</p>

							</li>

							<li>
								<i class="lni lni-trash-3"></i>
								<p class="js-classname">lni-trash-3</p>

							</li>

							<li>
								<i class="lni lni-tree-2"></i>
								<p class="js-classname">lni-tree-2</p>

							</li>

							<li>
								<i class="lni lni-trees-3"></i>
								<p class="js-classname">lni-trees-3</p>

							</li>

							<li>
								<i class="lni lni-trello"></i>
								<p class="js-classname">lni-trello</p>

							</li>

							<li>
								<i class="lni lni-trend-down-1"></i>
								<p class="js-classname">lni-trend-down-1</p>

							</li>

							<li>
								<i class="lni lni-trend-up-1"></i>
								<p class="js-classname">lni-trend-up-1</p>

							</li>

							<li>
								<i class="lni lni-trophy-1"></i>
								<p class="js-classname">lni-trophy-1</p>

							</li>

							<li>
								<i class="lni lni-trowel-1"></i>
								<p class="js-classname">lni-trowel-1</p>

							</li>

							<li>
								<i class="lni lni-truck-delivery-1"></i>
								<p class="js-classname">lni-truck-delivery-1</p>

							</li>

							<li>
								<i class="lni lni-tumblr"></i>
								<p class="js-classname">lni-tumblr</p>

							</li>

							<li>
								<i class="lni lni-turborepo"></i>
								<p class="js-classname">lni-turborepo</p>

							</li>

							<li>
								<i class="lni lni-twitch"></i>
								<p class="js-classname">lni-twitch</p>

							</li>

							<li>
								<i class="lni lni-twitter-old"></i>
								<p class="js-classname">lni-twitter-old</p>

							</li>

							<li>
								<i class="lni lni-typescript"></i>
								<p class="js-classname">lni-typescript</p>

							</li>

							<li>
								<i class="lni lni-uber"></i>
								<p class="js-classname">lni-uber</p>

							</li>

							<li>
								<i class="lni lni-uber-symbol"></i>
								<p class="js-classname">lni-uber-symbol</p>

							</li>

							<li>
								<i class="lni lni-ubuntu"></i>
								<p class="js-classname">lni-ubuntu</p>

							</li>

							<li>
								<i class="lni lni-underline"></i>
								<p class="js-classname">lni-underline</p>

							</li>

							<li>
								<i class="lni lni-unlink-2-angular-eft"></i>
								<p class="js-classname">lni-unlink-2-angular-eft</p>

							</li>

							<li>
								<i class="lni lni-unlocked-2"></i>
								<p class="js-classname">lni-unlocked-2</p>

							</li>

							<li>
								<i class="lni lni-unsplash"></i>
								<p class="js-classname">lni-unsplash</p>

							</li>

							<li>
								<i class="lni lni-upload-1"></i>
								<p class="js-classname">lni-upload-1</p>

							</li>

							<li>
								<i class="lni lni-upload-circle-1"></i>
								<p class="js-classname">lni-upload-circle-1</p>

							</li>

							<li>
								<i class="lni lni-user-4"></i>
								<p class="js-classname">lni-user-4</p>

							</li>

							<li>
								<i class="lni lni-user-multiple-4"></i>
								<p class="js-classname">lni-user-multiple-4</p>

							</li>

							<li>
								<i class="lni lni-vector-nodes-6"></i>
								<p class="js-classname">lni-vector-nodes-6</p>

							</li>

							<li>
								<i class="lni lni-vector-nodes-7"></i>
								<p class="js-classname">lni-vector-nodes-7</p>

							</li>

							<li>
								<i class="lni lni-vercel"></i>
								<p class="js-classname">lni-vercel</p>

							</li>

							<li>
								<i class="lni lni-vimeo"></i>
								<p class="js-classname">lni-vimeo</p>

							</li>

							<li>
								<i class="lni lni-visa"></i>
								<p class="js-classname">lni-visa</p>

							</li>

							<li>
								<i class="lni lni-vite"></i>
								<p class="js-classname">lni-vite</p>

							</li>

							<li>
								<i class="lni lni-vk"></i>
								<p class="js-classname">lni-vk</p>

							</li>

							<li>
								<i class="lni lni-vmware"></i>
								<p class="js-classname">lni-vmware</p>

							</li>

							<li>
								<i class="lni lni-volkswagen"></i>
								<p class="js-classname">lni-volkswagen</p>

							</li>

							<li>
								<i class="lni lni-volume-1"></i>
								<p class="js-classname">lni-volume-1</p>

							</li>

							<li>
								<i class="lni lni-volume-high"></i>
								<p class="js-classname">lni-volume-high</p>

							</li>

							<li>
								<i class="lni lni-volume-low"></i>
								<p class="js-classname">lni-volume-low</p>

							</li>

							<li>
								<i class="lni lni-volume-mute"></i>
								<p class="js-classname">lni-volume-mute</p>

							</li>

							<li>
								<i class="lni lni-volume-off"></i>
								<p class="js-classname">lni-volume-off</p>

							</li>

							<li>
								<i class="lni lni-vs-code"></i>
								<p class="js-classname">lni-vs-code</p>

							</li>

							<li>
								<i class="lni lni-vuejs"></i>
								<p class="js-classname">lni-vuejs</p>

							</li>

							<li>
								<i class="lni lni-wallet-1"></i>
								<p class="js-classname">lni-wallet-1</p>

							</li>

							<li>
								<i class="lni lni-watch-beat-1"></i>
								<p class="js-classname">lni-watch-beat-1</p>

							</li>

							<li>
								<i class="lni lni-water-drop-1"></i>
								<p class="js-classname">lni-water-drop-1</p>

							</li>

							<li>
								<i class="lni lni-webflow"></i>
								<p class="js-classname">lni-webflow</p>

							</li>

							<li>
								<i class="lni lni-webhooks"></i>
								<p class="js-classname">lni-webhooks</p>

							</li>

							<li>
								<i class="lni lni-wechat"></i>
								<p class="js-classname">lni-wechat</p>

							</li>

							<li>
								<i class="lni lni-weight-machine-1"></i>
								<p class="js-classname">lni-weight-machine-1</p>

							</li>

							<li>
								<i class="lni lni-whatsapp"></i>
								<p class="js-classname">lni-whatsapp</p>

							</li>

							<li>
								<i class="lni lni-wheelbarrow-empty"></i>
								<p class="js-classname">lni-wheelbarrow-empty</p>

							</li>

							<li>
								<i class="lni lni-wheelchair-1"></i>
								<p class="js-classname">lni-wheelchair-1</p>

							</li>

							<li>
								<i class="lni lni-windows"></i>
								<p class="js-classname">lni-windows</p>

							</li>

							<li>
								<i class="lni lni-wise"></i>
								<p class="js-classname">lni-wise</p>

							</li>

							<li>
								<i class="lni lni-wordpress"></i>
								<p class="js-classname">lni-wordpress</p>

							</li>

							<li>
								<i class="lni lni-www"></i>
								<p class="js-classname">lni-www</p>

							</li>

							<li>
								<i class="lni lni-www-cursor"></i>
								<p class="js-classname">lni-www-cursor</p>

							</li>

							<li>
								<i class="lni lni-x"></i>
								<p class="js-classname">lni-x</p>

							</li>

							<li>
								<i class="lni lni-xampp"></i>
								<p class="js-classname">lni-xampp</p>

							</li>

							<li>
								<i class="lni lni-xbox"></i>
								<p class="js-classname">lni-xbox</p>

							</li>

							<li>
								<i class="lni lni-xmark"></i>
								<p class="js-classname">lni-xmark</p>

							</li>

							<li>
								<i class="lni lni-xmark-circle"></i>
								<p class="js-classname">lni-xmark-circle</p>

							</li>

							<li>
								<i class="lni lni-xrp"></i>
								<p class="js-classname">lni-xrp</p>

							</li>

							<li>
								<i class="lni lni-yahoo"></i>
								<p class="js-classname">lni-yahoo</p>

							</li>

							<li>
								<i class="lni lni-yarn"></i>
								<p class="js-classname">lni-yarn</p>

							</li>

							<li>
								<i class="lni lni-ycombinator"></i>
								<p class="js-classname">lni-ycombinator</p>

							</li>

							<li>
								<i class="lni lni-yen"></i>
								<p class="js-classname">lni-yen</p>

							</li>

							<li>
								<i class="lni lni-youtube"></i>
								<p class="js-classname">lni-youtube</p>

							</li>

							<li>
								<i class="lni lni-youtube-kids"></i>
								<p class="js-classname">lni-youtube-kids</p>

							</li>

							<li>
								<i class="lni lni-youtube-music"></i>
								<p class="js-classname">lni-youtube-music</p>

							</li>

							<li>
								<i class="lni lni-zapier"></i>
								<p class="js-classname">lni-zapier</p>

							</li>

							<li>
								<i class="lni lni-zero-size"></i>
								<p class="js-classname">lni-zero-size</p>

							</li>

							<li>
								<i class="lni lni-zoom"></i>
								<p class="js-classname">lni-zoom</p>

							</li>
						</ul>
					</section>
				</main>
		<?php
		}
	}
	?>
<?php get_footer(); ?>