		<footer class="container">&copy; Fruitty 2025</footer>
		<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/js/scripts.js?version=<?php echo rand(10,1000); ?>"></script>
<?php /* wp_footer(); */ ?>
	</body>
</html>