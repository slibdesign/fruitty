<?php 
$__title 		= "404 Page Not Found";
$__description 	= "This page cannot be found";
$__keywords 	= "404, page not found"; 
$__canonical 	= get_permalink(); 
?>
<?php get_header(); ?>
		<main>
			<section>
				<header>
					<h1><?php _e( '404 Page Not Found', 'fruitty' ); ?></h1>
				</header>
				<div>
					<p><?php _e( 'This page content cannot be served', 'fruitty' ); ?></p>
					<?php get_search_form(); ?>
				</div>
			</section>
		</main>
<?php get_footer(); ?>
